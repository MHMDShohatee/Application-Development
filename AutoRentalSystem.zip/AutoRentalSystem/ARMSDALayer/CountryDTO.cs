﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARMSDALayer
{
    public class CountryDTO
    {
        public int CountryID { get; set; }
        public string CountryCode2Char { get; set; }
        public string CountryCode3Char { get; set; }
        public string CountryName { get; set; }
    }
}
