﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ARMSWinClient
{
    public partial class frmCreditCardUpdate : Form
    {
        public frmCreditCardUpdate()
        {
            InitializeComponent();
        }

        private void lblSTitle1_Click(object sender, EventArgs e)
        {

        }

        private void frmCreditCardUpdate_Load(object sender, EventArgs e)
        {

        }

        private void dtpExpDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void cbState_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtCreditCardLimit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCreditCardBalance_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbActivationStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

        }

        private void btnApply_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
